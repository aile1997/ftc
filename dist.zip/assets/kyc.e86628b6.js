import{d as j,e as S,D as F,G as H,S as G,W as k,s as W,P as Y,O as $,M as q,V as D,B as X,F as K,f as Q,A as Z,g as J,h as ee,i as te,j as P,R as re,E as ae,k as oe,l as ie,m as se,n as ne,o as M,p as le,T as _,C as ce}from"./Home.vue_vue_type_style_index_0_scoped_true_lang.b4ded4da.js";import{_ as de,d as O,o as fe,a as A,c as R,p as me,f as ue,g as ve,e as pe}from"./index.fb67fcbd.js";class _e extends j{constructor(e,d,f,s,r){super(),this.scene=e,this.camera=d,this.overrideMaterial=f,this.clearColor=s,this.clearAlpha=r!==void 0?r:0,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new S}render(e,d,f){const s=e.autoClear;e.autoClear=!1;let r,i;this.overrideMaterial!==void 0&&(i=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor&&(e.getClearColor(this._oldClearColor),r=e.getClearAlpha(),e.setClearColor(this.clearColor,this.clearAlpha)),this.clearDepth&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:f),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor&&e.setClearColor(this._oldClearColor,r),this.overrideMaterial!==void 0&&(this.scene.overrideMaterial=i),e.autoClear=s}}const he={defines:{BAND_MODE:2,CHROMA_SAMPLES:1},uniforms:{tDiffuse:{value:null},baseIor:{value:.075},bandOffset:{value:.003},jitterIntensity:{value:1},jitterOffset:{value:0}},vertexShader:`

		varying vec2 vUv;
		varying vec3 viewDir;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			viewDir = normalize( ( modelViewMatrix * vec4( position, 1.0 ) ).xyz );

		}

	`,fragmentShader:`

		varying vec2 vUv;
		varying vec3 viewDir;
		uniform float baseIor;
		uniform float bandOffset;
		uniform float jitterIntensity;
		uniform float jitterOffset;
		uniform sampler2D tDiffuse;

		#include <common>
		void main() {

			vec3 normal = vec3( ( 2.0 * vUv - vec2( 1.0 ) ), 1.0 );
			normal.z = 1.0;
			normal = normalize( normal );

			vec3 color;

			// if NO BANDS
			#if BAND_MODE == 0

			vec3 refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor );
			color = texture2D( tDiffuse, vUv + refracted.xy ).rgb;

			// if RGB or RYGCBV BANDS
			#else

			float index, randValue, offsetValue;
			float r, g, b, r_ior, g_ior, b_ior;
			vec3 r_refracted, g_refracted, b_refracted;
			vec4 r_sample, g_sample, b_sample;

			#if BAND_MODE == 2
			float y, c, v, y_ior, c_ior, v_ior;
			vec3 y_refracted, c_refracted, v_refracted;
			vec4 y_sample, c_sample, v_sample;
			#endif

			for ( int i = 0; i < CHROMA_SAMPLES; i ++ ) {

				index = float( i );
				randValue = rand( sin( index + 1. ) * gl_FragCoord.xy + vec2( jitterOffset, - jitterOffset ) ) - 0.5;
				offsetValue = index / float( CHROMA_SAMPLES ) + randValue * jitterIntensity;
				#if BAND_MODE == 1
				randValue *= 2.0;
				#endif

				// Paper describing functions for creating yellow, cyan, and violet bands and reforming
				// them into RGB:
				// https://web.archive.org/web/20061108181225/http://home.iitk.ac.in/~shankars/reports/dispersionraytrace.pdf
				r_ior = 1.0 + bandOffset * ( 0.0 + offsetValue );
				g_ior = 1.0 + bandOffset * ( 2.0 + offsetValue );
				b_ior = 1.0 + bandOffset * ( 4.0 + offsetValue );

				r_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / r_ior );
				g_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / g_ior );
				b_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / b_ior );

				r_sample = texture2D( tDiffuse, vUv + r_refracted.xy );
				g_sample = texture2D( tDiffuse, vUv + g_refracted.xy );
				b_sample = texture2D( tDiffuse, vUv + b_refracted.xy );

				#if BAND_MODE == 2
				y_ior = 1.0 + bandOffset * ( 1.0 + offsetValue );
				c_ior = 1.0 + bandOffset * ( 3.0 + offsetValue );
				v_ior = 1.0 + bandOffset * ( 5.0 + offsetValue );

				y_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / y_ior );
				c_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / c_ior );
				v_refracted = refract( vec3( 0.0, 0.0, - 1.0 ), normal, baseIor / v_ior );

				y_sample = texture2D( tDiffuse, vUv + y_refracted.xy );
				c_sample = texture2D( tDiffuse, vUv + c_refracted.xy );
				v_sample = texture2D( tDiffuse, vUv + v_refracted.xy );

				r = r_sample.r / 2.0;
				y = ( 2.0 * y_sample.r + 2.0 * y_sample.g - y_sample.b ) / 6.0;
				g = g_sample.g / 2.0;
				c = ( 2.0 * c_sample.g + 2.0 * c_sample.b - c_sample.r ) / 6.0;
				b = b_sample.b / 2.0;
				v = ( 2.0 * v_sample.b + 2.0 * v_sample.r - v_sample.g ) / 6.0;

				color.r += r + ( 2.0 * v + 2.0 * y - c ) / 3.0;
				color.g += g + ( 2.0 * y + 2.0 * c - v ) / 3.0;
				color.b += b + ( 2.0 * c + 2.0 * v - y ) / 3.0;
				#else
				color.r += r_sample.r;
				color.g += g_sample.g;
				color.b += b_sample.b;
				#endif

			}

			color /= float( CHROMA_SAMPLES );

			#endif

			gl_FragColor = vec4( color, 1.0 );

		}

	`},ge=()=>{const n=document.querySelector(".cursor"),e=new F;e.setDecoderPath("/draco/"),e.setDecoderConfig({type:"js"});const d=new H;d.setDRACOLoader(e);const f=document.createElement("div");document.body.appendChild(f);const s=new G;s.background=new S(789516);const r=new k({antialias:!1,powerPreference:"high-performance"});r.setPixelRatio(Math.min(window.devicePixelRatio,2)),r.setSize(window.innerWidth,window.innerHeight),r.outputEncoding=W,f.appendChild(r.domElement);const i=new Y(35,window.innerWidth/window.innerHeight,1,100);i.position.set(34,16,-20),s.add(i),window.addEventListener("resize",()=>{const t=window.innerWidth,o=window.innerHeight;i.aspect=t/o,i.updateProjectionMatrix(),r.setSize(t,o),u.setSize(t,o),r.setPixelRatio(2),v.uniforms.iResolution.value.set(t,o)});const a=new $(i,r.domElement);d.load("models/gltf/Skull.glb",function(t){t.scene.traverse(o=>{o.isMesh&&(h=new q(o).build())}),E()});let h,g={mousePos:{value:new D}},w=new X;const m={x:0,y:0},b=[],p=new D;function E(){for(let c=0;c<99e3;c++)h.sample(p),b.push(p.x,p.y,p.z);w.setAttribute("position",new K(b,3));const t=new Q({color:6032151,size:.1,blending:Z,transparent:!0,opacity:.8,depthWrite:!1,sizeAttenuation:!0,alphaMap:new J().load("/textures/particle-texture.jpg")});t.onBeforeCompile=function(c){c.uniforms.mousePos=g.mousePos,c.vertexShader=`
          uniform vec3 mousePos;
          varying float vNormal;
          
          ${c.vertexShader}`.replace("#include <begin_vertex>",`#include <begin_vertex>   
            vec3 seg = position - mousePos;
            vec3 dir = normalize(seg);
            float dist = length(seg);
            if (dist < 1.5){
              float force = clamp(1.0 / (dist * dist), -0., .5);
              transformed += dir * force;
              vNormal = force /0.5;
            }
          `)};const o=new ee(w,t);s.add(o)}function B(){a.enabled=!1,new _.Tween(i.position.set(0,-1,0)).to({x:2,y:-.4,z:6.5},6500).easing(_.Easing.Quadratic.InOut).start().onComplete(function(){a.enabled=!0,document.querySelector(".main--title").classList.add("ended"),I(),_.remove(this)})}B();function I(){a.enableDamping=!0,a.dampingFactor=.04,a.minDistance=.5,a.maxDistance=9,a.enableRotate=!0,a.enableZoom=!1,a.zoomSpeed=.5,a.autoRotate=!0}let x=window.innerWidth,y=window.innerHeight;const L=new _e(s,i),V=new te(x,y,{minFilter:P,magFilter:P,format:re}),u=new ae(r,V);u.setPixelRatio(Math.min(window.devicePixelRatio,2));const l=new oe(he);l.material.defines.CHROMA_SAMPLES=4,l.enabled=!0,l.material.uniforms.baseIor.value=.91,l.material.uniforms.bandOffset.value=.0019,l.material.uniforms.jitterIntensity.value=20.7,l.material.defines.BAND_MODE=2,u.addPass(L),u.addPass(l);let N=new ie(2,2),v=new se({side:ne,depthTest:!1,uniforms:{iTime:{value:0},iResolution:{value:new M},mousePos:{value:new M}},vertexShader:`
        varying vec2 vUv;
        void main(){
            vUv = uv;
            gl_Position = vec4( position, 1.0 );
        }`,fragmentShader:`
        varying vec2 vUv;
        uniform float iTime;
        uniform vec2 iResolution;
        uniform vec2 mousePos;

        #define N 16
        #define PI 3.14159265
        #define depth 1.0
        #define rate 0.3
        #define huecenter 0.5

        vec3 hsv2rgb( in vec3 c )
        {
            vec3 rgb = clamp( abs(mod(c.y*6.0+vec3(0.0,4.0,2.0),6.0)-3.0)-1.0, 0.0, .3 );
            return c.x * mix( vec3(.1), rgb, 1.0);
        }

        void main(){
            vec2 v = gl_FragCoord.xy/iResolution.xy;
            float t = iTime * 0.08;
            float r = 1.8;
            float d = 0.0;
            for (int i = 1; i < N; i++) {
                d = (PI / float(N)) * (float(i) * 14.0);
                r += length(vec2(rate*v.y, rate*v.x)) + 1.21;
                v = vec2(v.x+cos(v.y+cos(r)+d)+cos(t),v.y-sin(v.x+cos(r)+d)+sin(t));
            }
            r = (sin(r*0.09)*0.5)+0.5;            
            vec3 hsv = vec3(
                mod(mousePos.x + huecenter, 1.0), 1.0-0.5*pow(max(r,0.0)*1.2,0.5), 1.0-0.2*pow(max(r,0.4)*2.2,6.0)
            );
            gl_FragColor = vec4(hsv2rgb(hsv), 1.0);
        }`});const T=new le(N,v);s.add(T),v.uniforms.iResolution.value.set(x,y);const z=new ce;function C(){_.update(),a.update(),u.render(),l.material.uniforms.jitterOffset.value+=.01;const t=z.getElapsedTime();v.uniforms.iTime.value=t,requestAnimationFrame(C)}C(),document.addEventListener("mousemove",t=>{t.preventDefault(),U(t),m.x=t.clientX/window.innerWidth-.5,m.y=t.clientY/window.innerHeight-.5,g.mousePos.value.set(m.x,m.y,0),v.uniforms.mousePos.value.set(m.x,m.y)},!1);const U=t=>{const o=t.clientX,c=t.clientY;n.style.cssText=`left: ${o}px; top: ${c}px;`}},we=n=>(me("data-v-44786edd"),n=n(),ue(),n),be={class:"main--container"},xe=we(()=>ve("h1",{class:"main--title"},"Please fill in KYC carefully",-1)),ye=[xe],Ce=O({__name:"Home",setup(n){return fe(()=>{ge()}),(e,d)=>(A(),R("div",be,ye))}});var De=de(Ce,[["__scopeId","data-v-44786edd"]]);const Se=O({__name:"kyc",setup(n){return(e,d)=>(A(),R("main",null,[pe(De)]))}});export{Se as default};
